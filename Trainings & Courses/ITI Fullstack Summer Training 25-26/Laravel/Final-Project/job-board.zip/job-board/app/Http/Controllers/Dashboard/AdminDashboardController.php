<?php
namespace App\Http\Controllers\Dashboard;
use App\Http\Controllers\Controller;
use App\Models\Job;
use Illuminate\Http\Request;

class AdminDashboardController extends Controller
{
    public function pendingJobs()
    {
        
        $jobs = Job::where('status', 'pending')->with('employer')->paginate(5);

        return view('dashboard.adminDashboard', compact('jobs'));
    }

    public function approveJob($id)
    {
        $job = Job::findOrFail($id);
        $job->status = 'approved';
        $job->save();

        return back()->with('success', 'Job approved successfully.');
    }

    public function rejectJob($id)
    {
        $job = Job::findOrFail($id);
        $job->status = 'rejected';
        $job->save();

        return back()->with('success', 'Job rejected successfully.');
    }
}
