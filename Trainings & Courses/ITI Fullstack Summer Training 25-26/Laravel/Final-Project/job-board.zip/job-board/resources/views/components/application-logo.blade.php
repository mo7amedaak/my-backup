<img src="https://cdn-icons-png.flaticon.com/512/3135/3135768.png" alt="Job Board Logo" style="width:48px;height:48px;">
