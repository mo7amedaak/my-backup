<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<?php /**PATH /mnt/mywork/ITI Fullstack Summer Training 25-26/Laravel/Final-Project/job-board/resources/views/components/bootstrap-css.blade.php ENDPATH**/ ?>