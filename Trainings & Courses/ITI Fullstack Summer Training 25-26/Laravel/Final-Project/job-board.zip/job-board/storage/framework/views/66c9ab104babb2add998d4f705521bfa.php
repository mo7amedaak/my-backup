<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidate Dashboard</title>

    <!-- Bootstrap 5 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" />
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    <!-- Google Poppins Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            min-height: 100vh;
        }

        .card {
            border: none;
            border-radius: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.15);
        }

        /* Fade-in animation for cards */
        .card-animated {
            opacity: 0;
            transform: translateY(20px);
            animation: fadeIn 0.6s ease-out forwards;
        }
        @keyframes fadeIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .form-control, .form-select {
            border-radius: 50px;
        }
        .btn {
            border-radius: 50px;
        }
    </style>
</head>
<body class="bg-light">
<?php if (isset($component)) { $__componentOriginala591787d01fe92c5706972626cdf7231 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala591787d01fe92c5706972626cdf7231 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $attributes = $__attributesOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__attributesOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala591787d01fe92c5706972626cdf7231)): ?>
<?php $component = $__componentOriginala591787d01fe92c5706972626cdf7231; ?>
<?php unset($__componentOriginala591787d01fe92c5706972626cdf7231); ?>
<?php endif; ?>

<div class="container py-5">
    <h1 class="mb-4 text-primary fw-bold">Candidate Dashboard</h1>
    
    
    <form method="GET" action="<?php echo e(route('candidate.dashboard')); ?>" class="row g-3 mb-4 card p-4 shadow-sm">
        <div class="col-md-3">
            <input type="text" name="keyword" class="form-control" placeholder="Keyword"
                   value="<?php echo e(request('keyword')); ?>">
        </div>
        <div class="col-md-2">
            <input type="text" name="location" class="form-control" placeholder="Location"
                   value="<?php echo e(request('location')); ?>">
        </div>
        <div class="col-md-2">
            <input type="number" name="salary" class="form-control" placeholder="Min Salary"
                   value="<?php echo e(request('salary')); ?>" min="0" step="100" />
        </div>
        <div class="col-md-3">
            <select name="job_type" class="form-select">
                <option value="">Select Job Type</option>
                <option value="freelance" <?php echo e(request('job_type') == 'freelance' ? 'selected' : ''); ?>>Freelance</option>
                <option value="fulltime" <?php echo e(request('job_type') == 'fulltime' ? 'selected' : ''); ?>>Full Time</option>
                <option value="parttime" <?php echo e(request('job_type') == 'parttime' ? 'selected' : ''); ?>>Part Time</option>
                <option value="remote" <?php echo e(request('job_type') == 'remote' ? 'selected' : ''); ?>>Remote</option>
                <option value="internship" <?php echo e(request('job_type') == 'internship' ? 'selected' : ''); ?>>Internship</option>
            </select>
        </div>
        <div class="col-md-2 d-flex gap-2">
            <button type="submit" class="btn btn-primary w-100">
                <i class="fas fa-search me-1"></i> Search
            </button>
            <a href="<?php echo e(route('candidate.dashboard')); ?>" class="btn btn-outline-secondary px-3">
                <i class="fas fa-redo"></i>
            </a>
        </div>
    </form>

    
    <h2 class="mb-3 text-secondary">Available Jobs</h2>
    
    <div class="row g-4">
        <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div class="card card-animated" style="animation-delay: <?php echo e(0.1 * ($index + 1)); ?>s;">
                    <div class="card-body">
                        <h5 class="card-title fw-bold text-dark"><?php echo e($job->title); ?></h5>
                        <h6 class="card-subtitle mb-2 text-muted">
                            <i class="fas fa-building me-1"></i> <?php echo e($job->employer->name ?? 'N/A'); ?>

                        </h6>
                        <h6 class="card-subtitle mb-2 text-muted">
                            <i class="fas fa-map-marker-alt me-1"></i> <?php echo e($job->location); ?>

                        </h6>
                        
                        <div class="d-flex flex-wrap gap-2 my-3">
                             <?php
                                $typeColors = [
                                    'freelance' => 'badge bg-warning text-dark',
                                    'fulltime' => 'badge bg-success',
                                    'parttime' => 'badge bg-info text-dark',
                                    'remote' => 'badge bg-primary',
                                    'internship' => 'badge bg-secondary',
                                ];
                            ?>
                            <span class="<?php echo e($typeColors[$job->job_type] ?? 'badge bg-light text-dark'); ?>"><?php echo e(ucfirst($job->job_type)); ?></span>
                            <?php if($job->salary_min): ?>
                                <span class="badge bg-light text-dark">
                                    <i class="fas fa-dollar-sign"></i> <?php echo e(number_format($job->salary_min)); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <a href="<?php echo e(route('candidate.jobs.show', $job->id)); ?>" class="btn btn-sm btn-primary me-2">View Details</a>
                        
                        <form action="<?php echo e(route('applications.store', $job->id)); ?>" method="POST" enctype="multipart/form-data" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <div class="input-group mt-3">
                                <input type="file" name="resume" class="form-control form-control-sm" required>
                                <button type="submit" class="btn btn-sm btn-success px-3">Apply</button>
                            </div>
                            <?php $__errorArgs = ['resume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger mt-1 d-block"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php if(session('success_job_id') == $job->id): ?>
                                <small class="text-success mt-1 d-block"><?php echo e(session('success_message')); ?></small>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-muted fs-5 mt-4 card-animated">No jobs available at the moment.</p>
        <?php endif; ?>
    </div>

    
    <div class="mt-4">
        <?php echo e($jobs->links('pagination::bootstrap-5')); ?>

    </div>

</div>

<?php if (isset($component)) { $__componentOriginala751bb7a0201e698c73428a8d9619a40 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala751bb7a0201e698c73428a8d9619a40 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.bootstrap-js','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('bootstrap-js'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala751bb7a0201e698c73428a8d9619a40)): ?>
<?php $attributes = $__attributesOriginala751bb7a0201e698c73428a8d9619a40; ?>
<?php unset($__attributesOriginala751bb7a0201e698c73428a8d9619a40); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala751bb7a0201e698c73428a8d9619a40)): ?>
<?php $component = $__componentOriginala751bb7a0201e698c73428a8d9619a40; ?>
<?php unset($__componentOriginala751bb7a0201e698c73428a8d9619a40); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH /mnt/mywork/ITI Fullstack Summer Training 25-26/Laravel/Final-Project/job-board/resources/views/dashboard/candidateDashboard.blade.php ENDPATH**/ ?>