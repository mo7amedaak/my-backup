<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employer Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        .fade-in-section {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity 0.6s ease-out, transform 0.6s ease-out;
        }
        .fade-in-section.is-visible {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="#">
            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135768.png" alt="Job Board Logo" width="30" height="30" class="d-inline-block align-text-top me-2">
            JobBoard
        </a>

        <div class="d-flex align-items-center gap-3">
            <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-outline-primary btn-sm rounded-pill">
                Profile
            </a>

            <?php if(Auth::user()->role === 'admin'): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary btn-sm rounded-pill">Dashboard</a>
            <?php elseif(Auth::user()->role === 'employer'): ?>
                <a href="<?php echo e(route('employer.dashboard')); ?>" class="btn btn-primary btn-sm rounded-pill">Dashboard</a>
            <?php elseif(Auth::user()->role === 'candidate'): ?>
                <a href="<?php echo e(route('candidate.dashboard')); ?>" class="btn btn-primary btn-sm rounded-pill">Dashboard</a>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger btn-sm rounded-pill">
                    Logout
                </button>
            </form>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="fade-in-section">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold text-primary">Your Posted Jobs</h2>
                <p class="text-muted">Manage all your job listings from here</p>
            </div>
            <a href="<?php echo e(route('jobs.create')); ?>" class="btn btn-primary">+ Add New Job</a>
        </div>

        <?php if($jobs->count()): ?>
            <div class="row g-4">
                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 shadow-lg border-0 rounded-4">
                            <div class="card-body">
                                <h5 class="card-title fw-bold text-primary mb-2"><?php echo e($job->title); ?></h5>

                                <p class="mb-1 text-muted"><strong>Type:</strong> <?php echo e($job->type ?? 'N/A'); ?></p>
                                <p class="mb-1 text-muted"><strong>Status:</strong>
                                    <span class="badge 
                                        <?php echo e($job->status == 'approved' ? 'bg-success' : 
                                        ($job->status == 'pending' ? 'bg-warning text-dark' : 'bg-danger')); ?>">
                                        <?php echo e(ucfirst($job->status)); ?>

                                    </span>
                                </p>

                                <p class="text-muted small mt-2">Posted on <?php echo e($job->created_at->format('F d, Y')); ?></p>

                                <div class="d-flex gap-2 mt-4">
                                    <a href="<?php echo e(route('jobs.show', $job->id)); ?>" class="btn btn-outline-primary btn-sm flex-grow-1">View</a>
                                    <a href="<?php echo e(route('jobs.edit', $job->id)); ?>" class="btn btn-outline-secondary btn-sm flex-grow-1">Edit</a>
                                    <form action="<?php echo e(route('jobs.destroy', $job->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-outline-danger btn-sm flex-grow-1"
                                                onclick="return confirm('Are you sure you want to delete this job?')">
                                            Delete
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="d-flex justify-content-center mt-5">
                <?php echo e($jobs->links('pagination::bootstrap-5')); ?>

            </div>
        <?php else: ?>
            <div class="alert alert-info text-center shadow-lg rounded-4">
                You haven't posted any jobs yet.
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const sections = document.querySelectorAll('.fade-in-section');

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                }
            });
        }, {
            threshold: 0.1
        });

        sections.forEach(section => {
            observer.observe(section);
        });
    });
</script>
</body>
</html>
<?php /**PATH /mnt/mywork/ITI Fullstack Summer Training 25-26/Laravel/Final-Project/job-board/resources/views/dashboard/employerDashboard.blade.php ENDPATH**/ ?>