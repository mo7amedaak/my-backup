<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold text-primary" href="#">
            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135768.png" alt="Job Board Logo" width="30" height="30" class="d-inline-block align-text-top me-2">
            JobBoard
        </a>

        <div class="d-flex align-items-center gap-3">
            <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-outline-primary btn-sm rounded-pill">
                Profile
            </a>

            <?php if(Auth::user()->role === 'admin'): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-primary btn-sm rounded-pill">Dashboard</a>
            <?php elseif(Auth::user()->role === 'employer'): ?>
                <a href="<?php echo e(route('employer.dashboard')); ?>" class="btn btn-primary btn-sm rounded-pill">Dashboard</a>
            <?php elseif(Auth::user()->role === 'candidate'): ?>
                <a href="<?php echo e(route('candidate.dashboard')); ?>" class="btn btn-primary btn-sm rounded-pill">Dashboard</a>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger btn-sm rounded-pill">
                    Logout
                </button>
            </form>
        </div>
    </div>
</nav>
<?php /**PATH /mnt/mywork/ITI Fullstack Summer Training 25-26/Laravel/Final-Project/job-board/resources/views/components/navbar.blade.php ENDPATH**/ ?>